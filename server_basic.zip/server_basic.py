import uuid
import time
import mlflow
# from hair.config import ModelServerConfig
# from hair.mlflow import load_model_from_catalog
# from hair.serving import ServingApp, time_ms
# from hair.serving.prediction_logging import ModelMetadataInput, create_prediction_log_producer
from pydantic import BaseModel, ConfigDict, Field
# from hair.serving.online_feature_store_client import (
#     HaiStoreOnlineClient,
#     create_hai_online_store_client,
# )

from ray import serve
from starlette.requests import Request

# app = ServingApp(
#     title="HAI Demo Model Server",
#     summary="Reference implementation of an online model server for Hinge AI.",
# )
from fastapi import FastAPI


app = FastAPI()


class PredictionRequest(BaseModel):
    model_config = ConfigDict(use_attribute_docstrings=True)

    user_id: uuid.UUID
    """The user ID to predict for."""

    entities: list[str]
    """A list of entities associated with the user, used to retrieve features from the feature store"""


class PredictionResponse(BaseModel):
    score: float = Field(examples=[0.99], description="The predicted score.")

    deprecated_score: float | None = Field(
        deprecated=True,
        default=None,
        description="A deprecated score field.",
    )


@serve.deployment
@serve.ingress(app)
class HAIDemoModelServer:
    def __init__(self):
        pass

    @app.post("/inference")
    async def predict(self, request: Request, pred_req: PredictionRequest) -> PredictionResponse:


        score = 0.4
        print('received request', request)

        model_output = PredictionResponse(score=score)

        return model_output


base_model = HAIDemoModelServer.bind()  # type: ignore[attr-defined]
